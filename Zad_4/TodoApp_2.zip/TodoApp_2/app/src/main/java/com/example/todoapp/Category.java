package com.example.todoapp;

public enum Category {
    studia, dom
}
